Original write_log_file F/B outputs, preserved byte for byte.
From the financial-abm-lab repository, run:
.venv/bin/python -m experiments.YH012.inspect_saved_pair --run-dir /path/to/extracted/files
See manifest.json for file hashes and summary.json for ExperimentMeta and payload hashes.
